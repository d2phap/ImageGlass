﻿/*
 * imaeg - generic image utility in C#
 * Copyright (C) 2010  ed <tripflag@gmail.com>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License v2
 * (version 2) as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, refer to the following URL:
 * http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using System.Drawing.Imaging;

namespace ImageGlass.Core
{
    public class ImgMan
    {
        const int MAXQUE = 5;

        string root;
        List<Img> image;//luu danh sach img chua load
        List<Img> queue;//load 1 so img vao bo nho
        public ImgFilter filter;
        public int loadNext = 0;//load truoc vao hanh doi
        public bool imgError = false;

        public Bitmap ErrorImage()
        {
            return ImageGlass.Core.Core.Properties.Resources.Image_Error;            
        }

        public ImgMan()
        {
            image = new List<Img>();
            queue = new List<Img>();
        }

        public ImgMan(string root, string[] names)
        {
            //debug();
            this.root = root;
            image = new List<Img>();
            queue = new List<Img>();

            foreach (string name in names)
            {
                image.Add(new Img(name));
            }

            filter = new ImgFilter();
            Thread loada = new Thread(new ThreadStart(Loader));
            loada.Priority = ThreadPriority.BelowNormal;
            loada.IsBackground = true;
            loada.Start();

        }

        Label lb;
        void Debug()
        {
            lb = new Label();
            lb.Visible = true;
            lb.Dock = DockStyle.Fill;
            Form fm = new Form();
            fm.Controls.Add(lb);
            fm.Size = new Size(320, 900);
            fm.TopMost = true;
            fm.Show();
            System.Windows.Forms.Timer t = new System.Windows.Forms.Timer();
            t.Tick += new EventHandler(t_Tick);
            t.Interval = 100;
            t.Start();
        }
        void t_Tick(object sender, EventArgs e)
        {
            StringBuilder a = new StringBuilder();
            StringBuilder b = new StringBuilder();
            for (int i = 0; i < image.Count; i++)
            {
                if (image[i].finished)
                {
                    a.AppendLine(i + " - " + image[i].GetName());
                }
            }
            for (int i = 0; i < queue.Count; i++)
            {
                b.AppendLine(i + " - " + queue[i].GetName());
            }
            lb.Text = System.DateTime.Now.Ticks +
                "\n\n" + a.ToString() +
                "\n\n" + b.ToString();
        }

        /// <summary>
        /// Returns image i, applying all configured enhancements
        /// </summary>
        /// <param name="i">The image to return</param>
        /// <returns>Image i</returns>
        public Image Get(int i)
        {

            // Start off with unloading excessive images
            for (int a = 0; a < i - 3; a++)
            {
                image[a].Dispose();
            }
            for (int a = i + 3; a < image.Count; a++)
            {
                image[a].Dispose();
            }

            // New filter settings?
            if (filter.HasChanged())
            { //ALTERNATIVE_CODE
                foreach (Img im in image)
                {
                    im.Dispose();
                }
            }

            queue.Clear();
            queue.Add(image[i]);

            for (int j = 1; j <= loadNext; j++)
            {
                Enqueue(i + j);
            }

            //Enqueue(i + 1);
            //Enqueue(i + 2);
            //Enqueue(i - 1);
            //Enqueue(i - 2);

            while (!image[i].finished)
                Thread.Sleep(1);

            if (image[i].failed)
            {
                imgError = true;
                return new Bitmap(ImageGlass.Core.Core.Properties.Resources.Image_Error);
            }
            else
            {
                imgError = false;                
                return (Image)image[i].Get();
            }
                      
        }

        /// <summary>
        /// Enqueue image i at a lower priority (caching)
        /// </summary>
        /// <param name="i"></param>
        void Enqueue(int i)
        {
            if (i < 0 || i >= image.Count) return;
            if (!image[i].finished)
            {
                //foreach (Img j in queue)
                //if (image[i] == j) return;
                queue.Add(image[i]);
                //queue.Insert(1, image[i]);
            }
        }

        /// <summary>
        /// Worker thread; loads images.
        /// </summary>
        void Loader()
        {
            while (true)
            {
                if (queue.Count > 0)
                {
                    Img i = queue[0];
                    //queue.Clear();
                    queue.RemoveAt(0);

                    if (!i.finished)
                    {
                        //i.load(root);
                        i.Load(root, filter); //ALTERNATIVE_CODE
                        //i.set(filter.apply(i.get())); //ALTERNATIVE_CODE
                    }

                    
                    System.GC.Collect();
                }
                else
                {
                    
                    Thread.Sleep(10);
                }
            }
        }

        public int Length
        {
            get { return image.Count; }
            set { }
        }
        public string GetName(int i)
        {
            return image[i].GetName();
        }
        public string GetPath(int i)
        {
            return root + image[i].GetName();
        }
        public void SetName(int i, string s)
        {
            image[i].SetName(s);
        }
        public void Unload(int i)
        {
            if (image[i] != null)
                image[i].Dispose();
        }
        public void Remove(int i)
        {
            Unload(i);
            image.RemoveAt(i);
        }
        public void Dispose()
        {
            for (int i = 0; i < Length; i++)
            {
                Remove(i);
            }
            image.Clear();
            queue.Clear();
        }
    }
}
